

# Create your views here.

from django.shortcuts import render
from .models import Rectangle
from .forms import RectangleForm

def calculate_area(request):
    if request.method == 'POST':
        form = RectangleForm(request.POST)
        if form.is_valid():
            rectangle = form.save(commit=False)
            area = rectangle.calculate_area()
            return render(request, 'RectangleAreaApp/result.html', {'rectangle': rectangle, 'area': area})
    else:
        form = RectangleForm()
    return render(request, 'RectangleAreaApp/calculate.html', {'form': form})
