from django.db import models

# Create your models here.


from django.db import models

class Rectangle(models.Model):
    length = models.FloatField()
    width = models.FloatField()

    def calculate_area(self):
        return self.length * self.width

    def __str__(self):
        return f"Rectangle: Length {self.length}, Width {self.width}"
