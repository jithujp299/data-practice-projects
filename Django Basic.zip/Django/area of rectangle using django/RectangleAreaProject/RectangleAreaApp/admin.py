from django.contrib import admin

# Register your models here.


from .models import Rectangle

admin.site.register(Rectangle)