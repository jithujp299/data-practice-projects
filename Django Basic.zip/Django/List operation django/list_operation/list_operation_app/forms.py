# listoperations/forms.py

from django import forms

class ListForm(forms.Form):
    elements = forms.CharField()
