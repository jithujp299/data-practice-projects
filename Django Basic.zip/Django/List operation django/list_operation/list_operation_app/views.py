# listoperations/views.py

from django.shortcuts import render
from .forms import ListForm

def list_operations(request):
    result = None
    form = ListForm()
    context = {'form': form}

    if request.method == 'POST':
        form = ListForm(request.POST)
        if form.is_valid():
            elements_str = form.cleaned_data['elements']
            elements_list = [int(x) for x in elements_str.split(',')]

            sum_of_elements = sum(elements_list)
            duplicates = {x for x in elements_list if elements_list.count(x) > 1}
            is_empty = len(elements_list) == 0
            average = sum_of_elements / len(elements_list) if elements_list else 0

            result = {
                'sum': sum_of_elements,
                'duplicates': duplicates,
                'is_empty': is_empty,
                'average': average,
            }
            context['result'] = result

    return render(request, 'front.html', context)
