from django.apps import AppConfig


class ListOperationAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'list_operation_app'
