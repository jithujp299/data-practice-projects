from django.urls import path
from .views import reverse_string
urlpatterns = [
    path('',reverse_string ,name='reversed_string'),
]