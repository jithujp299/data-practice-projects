from django.apps import AppConfig


class ReverseStringAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reverse_string_app'
