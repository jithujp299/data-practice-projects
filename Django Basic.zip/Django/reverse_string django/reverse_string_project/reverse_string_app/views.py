from django.shortcuts import render
from django.http import HttpResponse
from django.utils.html import escape
# Create your views here.

def reverse_string(request):
    reversed_string = None
    if request.method == 'POST':
        input_string = request.POST.get('text', '')
        input_string_escaped = escape(input_string)
        reversed_string = input_string_escaped[::-1]
    return render(request, 'reverse_string.html', {'reversed_string': reversed_string})