import math as m

print("floor = ",m.floor(2.345))
print("ceil = ",m.ceil(2.599))
print("sqrt = ",m.sqrt(100))
print("pow = ",m.pow(2,6))
print("sin = ",m.sin(23))
print("cos = ",m.cos(30))
print("log = ",m.log(23))