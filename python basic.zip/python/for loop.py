#fruits=["apple","banana","cherry","pineapple","orange"]
#for x in fruits:
#   print(x)

#fruits=["apple","banana","cherry","pineapple","orange"]
#for x in "banana":
#  print(x)

#fruits=["apple","banana","cherry","pineapple","orange"]
#for x in fruits:
#   print(x)
#if x=="banana":
# "break"

#fruits=["apple","banana","cherry","pineapple","orange"]
#for x in fruits:
 #if x=="orange":
  # break
#print(x)


#fruits=["apple","banana","cherry","pineapple","orange"]
#for x in fruits:
#  if x=="banana":
 #  continue
#print(x)

#for x in range(6):
#   print(x)

#for x in range(2,6):
#   print(x)

#for x in range(2,30,3):
#   print(x)


#for x in range(2,8):
#  print(x)
#else:
#  print("finally finished")

#for x in range(2,9):
#  if x==4: break
#  print(x)
#else:
# print("finally finished")
 
#for x in range(2,9):
# if x==4: 
#  print(x)
#  break
#else:
#   print("finally finished")

#adj=["red","big","tasty"]
#fruits=["apple","banana","cherry"]
#for y in adj:
#for y in fruits:
# print(x,y)

#adj=["red","big","tasty"]
#fruits=["apple","banana","cherry"]
#for x in adj:
#for y in fruits:
# print(y,x)

#for x in [0,1,2]:
#  pass

#x=[10,20,30,40]

#for x in range(20,90,20):
 #  print(x)

#x=[10,20,30,40]
#for y in x:
#   print(y*2)

#x=["i love my india "]
#for y in x:
 #   print(y*7)

#for x in range(2,224,2):
#   print(x)

#for y in range(3,100,2):
#    print(y)

