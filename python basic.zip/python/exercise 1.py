age=int(input("enter your age:"))

years_left=90-age
days_left=years_left*365
month_left=years_left*12
week_left=years_left*52

print(f"you left {years_left} years, {days_left} days , {month_left} month and {week_left} weeks")