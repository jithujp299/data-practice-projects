# mark=int(input("enter your mark"))
# if mark > 90:
#     print("grade a")
# elif mark >80:
#     print("grade b")
# elif mark>70:
#     print("grade c")
# elif mark>60:
#     print("grade d")
# else:
#     print('failed')


# month=input("enter month")
# if month=="january":
#     print(1)
# elif month=="february":
#     print(2)
# elif month=="march":
#     print(3)
# elif month=="april":
#     print(4)
# elif month=="may":
#     print(5)
# elif month=="june":
#     print(6)
# elif month=="july":
#     print(7)
# elif month=="august":
#     print(8)
# elif month=="september":
#     print(9)
# elif month=="october":
#     print(10)
# elif month=="november":
#     print(11)
# elif month=="december":
#     print(12)
# else:
#     print("invalid")