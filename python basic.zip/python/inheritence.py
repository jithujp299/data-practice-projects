class parent:
    def __init__(self,name,contact):
        self.name=name
        self.contact=contact
    def address(self):
        print(self.name,self.contact)
class docter(parent):
    pass
class patient(parent):
    pass
doc1=docter("john",123456)
doc2=patient("jithu",938494)

doc1.address()
doc2.address()