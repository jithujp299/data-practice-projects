class hospital:
    def __init__(self,admin,doctor,sister,dep):
        self.admin=admin
        self.doctor=doctor
        self.sister=sister
        self.dep=dep
    def getdetails(self):
        self.admin=input("enter the name of admin")
        self.doctor=input("enter the name of doctor")
        self.sister=input("enter the name of sister")
        self.dep=input("enter the dep")
class department(hospital):
  def display (self):
        print(self.admin,self.doctor,self.sister,self.dep)
class patient(department):
    def __init__(self, name, age, num, disease):
        self.name=name
        self.age=age
        self.num=num
        self.disease=disease
    def getd(self):
        self.name=input("enter patient's name")
        self.age=input("enter patient's age")
        self.num=input("enter token number")
        self.disease=input("enter the disease")
    def putdetails(self):
        print(self.name,self.age,self.num,self.disease)
obj=patient('','','','')
obj.getdetails()
obj.display()
obj.getd()
obj.putdetails()
