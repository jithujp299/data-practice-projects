size=input("what size pizza you want (S,M,L)")
bill=0
if size == 's' or size=='S':
    bill+=100
    print("the price of smaller pizza is 100rs")
elif size=='M' or size=='m':
    bill+=200
    print("the price of the pizza is 200rs")
else: 
    size == 'L' or size=='l'
    bill+=300
add_pepperoni=input("do you want pepperonie (y/N)")
if add_pepperoni=='Y'or add_pepperoni=='y':
   if size=='s' or size=='S':
       bill+=30
   else:
       bill+=50
extra_cheese =input("do you ant any extra cheese (Y/N)")
if extra_cheese=='y' or extra_cheese=='Y':
    if size=='s' or size=='S':
        bill+=30
    else:
        bill+=50
print(f"your total price = {bill}")