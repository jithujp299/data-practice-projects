import math


def parameter(width,height,cover):
    area=height*width
    no_of_cans=math.ceil(area/cover)
    print(f"you will need {no_of_cans} cans of paints")
w=int(input("enter the width of wall in meters : \n"))
h=int(input("enter the height of walls in meters : \n"))
coverage=7
parameter(width=w,height=h,cover=coverage)