student=[
    {
        "name":"jithu",
        "roll_no":20,
        "class":10,
        "course":"cabm"
     },
     {
         "name":"arjun",
         "roll_no":23,
         "glass":10,
         "course":"cbm"
     }
]

def student_details(name,roll_no,glass,course):
    newstudent_details={}
    newstudent_details["name"]=name
    newstudent_details["roll_no"]=roll_no
    newstudent_details["class"]=glass
    newstudent_details["course"]=course
    student.append(newstudent_details)

student_details("stylash",23,11,"cabm")
print(student)