car={"brand":"ford","model":"mustang","year": 1998}
x=car.items()
print(x)
car["year"]=2020
print(x)
#x=car.values()
#print(x)
#x=car.keys()
#x=car["model"]
#print(x)
#car.update({"color":"red"})
#print(car)
car.popitem()
print(car)
#car.pop("model")
#print(car)
#del car["model"]
#print(car)