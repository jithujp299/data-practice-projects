weight=input("enter the weight in kg:" )
height=input("enter the height in m:")

bmi=int(weight)/float(height) ** 2
print(int(bmi))