for i in range (7):
    for j in range (5):
        if i==0 or (j==2 and (i!=0)) or (i==6  and (j!=3 and j!=4)):
            print("*",end=" ")
        else:
            print(end="  ")
    print()