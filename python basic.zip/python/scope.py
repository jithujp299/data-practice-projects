def check_scope():
    def do_local_scope():
        text="local_scope"
    def do_non_local():
        nonlocal text
        text="non_local"
    def global_scope():
        global text
        text="global"  
    text="default" 
    do_local_scope()
    print("do local scope: "+text)
    do_non_local()
    print("non local scope: "+text)
    global_scope()
    print("global scope: "+text)


check_scope()
print("global_scope:"+text)
         