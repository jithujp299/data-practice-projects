number=int(input("enter the number:"))
if number%2 == 0:
    print("even number")
else:
    print("odd number")
