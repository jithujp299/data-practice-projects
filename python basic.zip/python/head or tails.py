import random


coin= random.randint(0,1)
print(coin)
if coin==1:
    print("heads")
else:
    print("tails")