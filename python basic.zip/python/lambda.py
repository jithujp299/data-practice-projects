#x=lambda a: a+10
#print(x(8))

#  x=lambda a,b: a*b
# print(x(3,7))

# x=lambda a,b,c: a+b+c
# print(x(3,6,9))

# x=lambda a,b: a/b
# print(x(3,7))

# x=lambda a,b,c: a*b/c
# print(x(30,6,9))

