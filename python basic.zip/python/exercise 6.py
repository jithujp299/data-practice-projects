
#fruits={"apple","orange","mango","strawberry","blueberry","apple"}
#print(fruits)
#print(len(fruits))
#print("papaya"in fruits)
#print("apple"in fruits)
#fruits.add("papaya")
#print(fruits)
x={"e","r","u","o","y","i"}
y={"a","b","c","d"}
x.update(y)
print(x)
x.remove("a")
print(x)
x.pop()
print(x)
x.discard("i")
print(x)
# x.clear()
# print(x)
# del fruits
# print(fruits)
#a={1,12,3,4,5,66,666,77,88,883}
#b={12,13,14,15,16,17,18,19}
# a.intersection_update(b)
# print(a)
#c= a.union(b)
#print(c)

